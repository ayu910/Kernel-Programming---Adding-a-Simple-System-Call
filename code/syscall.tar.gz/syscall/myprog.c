/*
 * Description:         A test program for system call for sys_s2_encrypt()
 * Version:             1.0
 * Author:              Ayush Sharma
*/

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUFF_SIZE 32767

int main(int argc, char *argv[])
{
	char opt;
	int key = 0;
	char input_string[BUFF_SIZE];
	int retval = 0;

	/*Implementation of GETOPT for extracting arguments*/
	while((opt = getopt(argc, argv,"s:k:")) != -1)
	{
		switch(opt)
		{
			case 's':
				strcpy(input_string, optarg);
				break;
			case 'k':
				key = atoi(optarg);
				break;
			default:
				printf("Option Incorrect! Usage: -s for String and -k for Key.");
				return 1;
		}
	}
	/*SYSCALL to sys_s2_encrypt()*/
	retval = syscall(548,input_string,key);
	printf("\nReturned value is : %d", retval);	
	return 0;
}
